import type { ConflictLog } from "@/lib/sync/types";

export function ConflictCard({ conflict }: { conflict: ConflictLog }) {
  return (
    <div className="rounded-lg border border-warning/30 bg-warning/5 p-3 fade-in">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-warning">Conflict resolved</span>
        <span className="text-[10px] text-muted-foreground">{new Date(conflict.at).toLocaleTimeString()}</span>
      </div>
      <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <Side label="Phone (incoming)" entry={conflict.incoming} winning={conflict.winning === conflict.incoming} />
        <Side label="Laptop (existing)" entry={conflict.existing} winning={conflict.winning === conflict.existing} />
        <div className="rounded border border-success/30 bg-success/10 p-2 text-xs">
          <div className="text-[10px] uppercase tracking-wider text-success">Winner</div>
          <div className="mt-1 font-mono">{conflict.winning.status} v{conflict.winning.version}</div>
          <div className="mt-1 text-muted-foreground">{conflict.reason}</div>
        </div>
      </div>
      <div className="mt-2 text-[11px] text-muted-foreground">Task: <code className="font-mono">{conflict.taskId}</code></div>
    </div>
  );
}

function Side({ label, entry, winning }: { label: string; entry: ConflictLog["incoming"]; winning: boolean }) {
  return (
    <div className={`rounded border p-2 text-xs ${winning ? "border-success/40 bg-success/5" : "border-border bg-surface-2/40 opacity-80"}`}>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-mono">{entry.status} v{entry.version}</div>
      <div className="mt-1 text-[10px] text-muted-foreground font-mono">{entry.deviceId}</div>
    </div>
  );
}
