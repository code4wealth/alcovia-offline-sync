import { useSyncStore } from "@/lib/sync/store";

export function DeviceStateCard() {
  const s = useSyncStore();
  const pending = s.queue.filter((e) => e.status === "PENDING" || e.status === "SYNCING").length;
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">Device State</div>
      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
        <dt className="text-muted-foreground">Device ID</dt>
        <dd className="font-mono text-xs">{s.deviceId}</dd>
        <dt className="text-muted-foreground">Online</dt>
        <dd className={s.online ? "text-success" : "text-warning"}>{s.online ? "Yes" : "No"}</dd>
        <dt className="text-muted-foreground">Pending events</dt>
        <dd className="tabular-nums">{pending}</dd>
        <dt className="text-muted-foreground">Local version</dt>
        <dd className="tabular-nums">v{s.localVersion}</dd>
        <dt className="text-muted-foreground">Last sync</dt>
        <dd>{s.lastSyncAt ? new Date(s.lastSyncAt).toLocaleTimeString() : "—"}</dd>
        <dt className="text-muted-foreground">Demo mode</dt>
        <dd className={s.demoMode ? "text-primary" : ""}>{s.demoMode ? "On (fast)" : "Off"}</dd>
      </dl>
    </div>
  );
}
