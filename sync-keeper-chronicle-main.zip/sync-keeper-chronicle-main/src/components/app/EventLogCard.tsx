import type { SyncEvent } from "@/lib/sync/types";

const statusColor: Record<string, string> = {
  PENDING: "bg-warning/15 text-warning border-warning/30",
  SYNCING: "bg-primary/15 text-primary border-primary/30",
  SYNCED: "bg-success/15 text-success border-success/30",
  REJECTED_DUPLICATE: "bg-danger/15 text-danger border-danger/30",
};

export function EventLogCard({ event }: { event: SyncEvent }) {
  return (
    <div className="rounded-lg border border-border bg-surface-2/40 p-3 fade-in">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className={`rounded-md border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${statusColor[event.status]}`}>
            {event.status.replace("_", " ")}
          </span>
          <span className="text-sm font-medium truncate">{event.type}</span>
        </div>
        <code className="font-mono text-[10px] text-muted-foreground shrink-0">{event.id}</code>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
        <span>v{event.logicalVersion}</span>
        <span className="font-mono">{event.deviceId}</span>
        <span>{new Date(event.createdAt).toLocaleTimeString()}</span>
        {event.rejectionReason && <span className="text-danger">⚠ {event.rejectionReason}</span>}
      </div>
      <pre className="mt-2 overflow-x-auto rounded bg-background/60 p-2 text-[11px] font-mono text-muted-foreground">
{JSON.stringify(event.payload, null, 2)}
      </pre>
    </div>
  );
}
