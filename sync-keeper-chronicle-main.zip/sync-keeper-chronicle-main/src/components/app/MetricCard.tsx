import type { ReactNode } from "react";

interface Props {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  accent?: "primary" | "success" | "warning" | "danger" | "default";
}

const accentMap = {
  primary: "text-primary",
  success: "text-success",
  warning: "text-warning",
  danger: "text-danger",
  default: "text-foreground",
};

export function MetricCard({ label, value, hint, icon, accent = "default" }: Props) {
  return (
    <div className="glass rounded-xl p-5 fade-in">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
        {icon && <span className={`text-lg ${accentMap[accent]}`}>{icon}</span>}
      </div>
      <div className={`mt-2 text-3xl font-semibold tabular-nums ${accentMap[accent]}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}
