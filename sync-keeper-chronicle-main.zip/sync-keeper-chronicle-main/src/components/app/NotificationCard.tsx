import type { NotificationLog } from "@/lib/sync/types";

export function NotificationCard({ n }: { n: NotificationLog }) {
  const blocked = n.duplicatePrevented;
  return (
    <div className={`rounded-lg border p-3 fade-in ${blocked ? "border-danger/30 bg-danger/5" : "border-success/30 bg-success/5"}`}>
      <div className="flex items-center justify-between">
        <span className={`text-xs font-semibold uppercase tracking-wider ${blocked ? "text-danger" : "text-success"}`}>
          {blocked ? "Duplicate prevented" : "n8n notification sent"}
        </span>
        <span className="text-[10px] text-muted-foreground">{new Date(n.at).toLocaleTimeString()}</span>
      </div>
      <div className="mt-1 text-xs text-muted-foreground">
        {n.type} · session <code className="font-mono">{n.sessionId}</code>
      </div>
    </div>
  );
}
