import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { SyncStatusBadge } from "./SyncStatusBadge";
import { useSyncStore } from "@/lib/sync/store";

const nav = [
  { to: "/", label: "Dashboard" },
  { to: "/focus", label: "Focus" },
  { to: "/syllabus", label: "Syllabus" },
  { to: "/dev", label: "Dev Panel" },
  { to: "/inspector", label: "Sync Inspector" },
];

export function Shell({ children }: { children?: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const online = useSyncStore((s) => s.online);
  const setOnline = useSyncStore((s) => s.setOnline);
  const demo = useSyncStore((s) => s.demoMode);
  const setDemo = useSyncStore((s) => s.setDemoMode);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6">
          <Link to="/" className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-primary to-primary/60 text-sm font-bold">A</div>
            <div className="leading-tight">
              <div className="text-sm font-semibold">Alcovia</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Study Sync</div>
            </div>
          </Link>
          <nav className="ml-2 hidden items-center gap-1 md:flex">
            {nav.map((n) => {
              const active = path === n.to || (n.to !== "/" && path.startsWith(n.to));
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={`rounded-md px-3 py-1.5 text-sm transition-colors ${
                    active ? "bg-surface-2 text-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {n.label}
                </Link>
              );
            })}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => setDemo(!demo)}
              className={`hidden sm:inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                demo ? "border-primary/40 bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
              }`}
              title="Demo mode shortens sessions for recording"
            >
              <span className={`h-1.5 w-1.5 rounded-full ${demo ? "bg-primary" : "bg-muted-foreground"}`} />
              Demo Mode
            </button>
            <button
              onClick={() => setOnline(!online)}
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                online ? "border-success/40 bg-success/10 text-success" : "border-warning/40 bg-warning/10 text-warning"
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${online ? "bg-success" : "bg-warning"}`} />
              {online ? "Online" : "Offline"}
            </button>
            <SyncStatusBadge />
          </div>
        </div>
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-2 md:hidden">
          {nav.map((n) => {
            const active = path === n.to || (n.to !== "/" && path.startsWith(n.to));
            return (
              <Link
                key={n.to}
                to={n.to}
                className={`shrink-0 rounded-md px-3 py-1.5 text-sm ${
                  active ? "bg-surface-2 text-foreground" : "text-muted-foreground"
                }`}
              >
                {n.label}
              </Link>
            );
          })}
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">{children ?? <Outlet />}</main>
    </div>
  );
}
