import { useSyncStore } from "@/lib/sync/store";

export function SyncStatusBadge() {
  const online = useSyncStore((s) => s.online);
  const pending = useSyncStore((s) => s.queue.filter((e) => e.status === "PENDING" || e.status === "SYNCING").length);
  const last = useSyncStore((s) => s.lastSyncAt);

  const color = !online ? "text-warning" : pending ? "text-primary" : "text-success";
  const label = !online ? "Offline" : pending ? `Syncing ${pending}` : "Synced";

  return (
    <div className="inline-flex items-center gap-3 rounded-full border border-border bg-surface-2/60 px-3 py-1.5 text-xs font-medium">
      <span className={`pulse-dot ${color}`}>{label}</span>
      <span className="text-muted-foreground">
        {last ? `· ${new Date(last).toLocaleTimeString()}` : "· never synced"}
      </span>
    </div>
  );
}
