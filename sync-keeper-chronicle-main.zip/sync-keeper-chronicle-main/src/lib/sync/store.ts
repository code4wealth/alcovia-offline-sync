import { create } from "zustand";
import { persist } from "zustand/middleware";
import { nanoid } from "nanoid";
import type {
  ConflictLog,
  NotificationLog,
  Subject,
  SyncEvent,
  Task,
  TaskStatus,
  FocusSession,
} from "./types";

// --- Seed data ---
const seedSubjects = (): Subject[] => [
  {
    id: "s1",
    title: "Mathematics",
    emoji: "∑",
    chapters: [
      {
        id: "c1",
        title: "Linear Algebra",
        tasks: [
          { id: "t1", title: "Vectors & Spaces", status: "DONE", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t2", title: "Matrix Operations", status: "IN_PROGRESS", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t3", title: "Eigenvalues", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
        ],
      },
      {
        id: "c2",
        title: "Calculus",
        tasks: [
          { id: "t4", title: "Limits", status: "DONE", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t5", title: "Derivatives", status: "IN_PROGRESS", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t6", title: "Integrals", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
        ],
      },
    ],
  },
  {
    id: "s2",
    title: "Physics",
    emoji: "⚛",
    chapters: [
      {
        id: "c3",
        title: "Mechanics",
        tasks: [
          { id: "t7", title: "Newton's Laws", status: "DONE", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t8", title: "Energy & Momentum", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
        ],
      },
      {
        id: "c4",
        title: "Thermodynamics",
        tasks: [
          { id: "t9", title: "Laws of Thermo", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t10", title: "Entropy", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
        ],
      },
    ],
  },
  {
    id: "s3",
    title: "Computer Science",
    emoji: "</>",
    chapters: [
      {
        id: "c5",
        title: "Distributed Systems",
        tasks: [
          { id: "t11", title: "CAP Theorem", status: "DONE", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t12", title: "CRDTs", status: "IN_PROGRESS", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
          { id: "t13", title: "Consensus", status: "NOT_STARTED", version: 1, updatedAt: Date.now(), updatedBy: "seed" },
        ],
      },
    ],
  },
];

interface AppliedEvent {
  eventId: string;
  type: string;
  appliedAt: number;
}

interface State {
  // device
  deviceId: string;
  demoMode: boolean;
  online: boolean;
  lastSyncAt: number | null;
  localVersion: number;

  // gamification
  streak: number;
  coins: number;
  todayFocusMinutes: number;
  lastSessionDate: string | null;

  // sessions
  activeSession: FocusSession | null;
  appSwitchCount: number;

  // syllabus
  subjects: Subject[];

  // sync
  queue: SyncEvent[];
  // server simulation
  serverEventsApplied: AppliedEvent[]; // for idempotency
  serverSubjects: Subject[]; // server view of syllabus
  serverVersion: number;

  // logs
  conflicts: ConflictLog[];
  notifications: NotificationLog[];

  // actions
  setOnline: (v: boolean) => void;
  setDemoMode: (v: boolean) => void;
  startSession: (durationSec: number) => void;
  failSession: () => void;
  completeSession: () => void;
  registerAppSwitch: () => void;
  updateTask: (taskId: string, status: TaskStatus) => void;
  enqueue: (e: Omit<SyncEvent, "id" | "status" | "createdAt" | "deviceId" | "logicalVersion">) => SyncEvent;
  syncNow: () => Promise<void>;
  replayLast: () => Promise<void>;
  generateConflict: () => void;
  clearLocal: () => void;
  tickSession: () => void;
}

const todayKey = () => new Date().toISOString().slice(0, 10);

const findTask = (subjects: Subject[], taskId: string): { task: Task; subject: Subject; chapter: any } | null => {
  for (const s of subjects)
    for (const c of s.chapters)
      for (const t of c.tasks) if (t.id === taskId) return { task: t, subject: s, chapter: c };
  return null;
};

const cloneSubjects = (s: Subject[]): Subject[] => JSON.parse(JSON.stringify(s));

export const useSyncStore = create<State>()(
  persist(
    (set, get) => ({
      deviceId: `dev_${nanoid(6)}`,
      demoMode: true,
      online: true,
      lastSyncAt: null,
      localVersion: 1,

      streak: 3,
      coins: 120,
      todayFocusMinutes: 0,
      lastSessionDate: null,

      activeSession: null,
      appSwitchCount: 0,

      subjects: seedSubjects(),

      queue: [],
      serverEventsApplied: [],
      serverSubjects: seedSubjects(),
      serverVersion: 1,

      conflicts: [],
      notifications: [],

      setOnline: (v) => {
        set({ online: v });
        if (v) void get().syncNow();
      },
      setDemoMode: (v) => set({ demoMode: v }),

      startSession: (durationSec) => {
        const realDuration = get().demoMode ? Math.min(durationSec, 8) : durationSec;
        const session: FocusSession = {
          id: `sess_${nanoid(10)}`,
          durationSec: realDuration,
          startedAt: Date.now(),
          coinsEarned: 0,
          deviceId: get().deviceId,
        };
        set({ activeSession: session, appSwitchCount: 0 });
        get().enqueue({
          type: "SESSION_STARTED",
          payload: { sessionId: session.id, durationSec: realDuration },
        });
      },

      registerAppSwitch: () => set((s) => ({ appSwitchCount: s.appSwitchCount + 1 })),

      tickSession: () => {
        const s = get().activeSession;
        if (!s) return;
        const elapsed = (Date.now() - s.startedAt) / 1000;
        if (elapsed >= s.durationSec) get().completeSession();
      },

      failSession: () => {
        const s = get().activeSession;
        if (!s) return;
        const ended = { ...s, endedAt: Date.now(), outcome: "FAILED" as const };
        set({ activeSession: null });
        get().enqueue({
          type: "SESSION_FAILED",
          payload: { sessionId: s.id, reason: "user_gave_up" },
        });
        void ended;
      },

      completeSession: () => {
        const s = get().activeSession;
        if (!s) return;
        const coins = Math.max(5, Math.round(s.durationSec / 6));
        const minutes = Math.round(s.durationSec / 60) || 1;
        const today = todayKey();
        const prevDate = get().lastSessionDate;
        const streak = prevDate === today ? get().streak : get().streak + 1;
        set({
          activeSession: null,
          coins: get().coins + coins,
          todayFocusMinutes: get().todayFocusMinutes + minutes,
          streak,
          lastSessionDate: today,
        });
        get().enqueue({
          type: "SESSION_COMPLETED",
          payload: { sessionId: s.id, coins, minutes },
        });
      },

      updateTask: (taskId, status) => {
        const subjects = cloneSubjects(get().subjects);
        const found = findTask(subjects, taskId);
        if (!found) return;
        found.task.status = status;
        found.task.version += 1;
        found.task.updatedAt = Date.now();
        found.task.updatedBy = get().deviceId;
        set({ subjects, localVersion: get().localVersion + 1 });
        get().enqueue({
          type: "TASK_UPDATED",
          payload: { taskId, status, version: found.task.version },
        });
      },

      enqueue: (e) => {
        const evt: SyncEvent = {
          id: `evt_${nanoid(12)}`,
          status: "PENDING",
          createdAt: Date.now(),
          deviceId: get().deviceId,
          logicalVersion: get().localVersion,
          ...e,
        };
        set({ queue: [...get().queue, evt] });
        if (get().online) {
          // fire and forget
          setTimeout(() => void get().syncNow(), 250);
        }
        return evt;
      },

      syncNow: async () => {
        if (!get().online) return;
        const pending = get().queue.filter((e) => e.status === "PENDING");
        if (!pending.length) {
          set({ lastSyncAt: Date.now() });
          return;
        }
        set({
          queue: get().queue.map((e) =>
            e.status === "PENDING" ? { ...e, status: "SYNCING" as const } : e,
          ),
        });
        // simulate network latency
        await new Promise((r) => setTimeout(r, 500));

        const applied = [...get().serverEventsApplied];
        const conflicts = [...get().conflicts];
        const notifications = [...get().notifications];
        let serverSubjects = cloneSubjects(get().serverSubjects);
        let serverVersion = get().serverVersion;

        const newQueue = get().queue.map((e) => {
          if (e.status !== "SYNCING") return e;
          // idempotency check
          if (applied.find((a) => a.eventId === e.id)) {
            if (e.type === "SESSION_COMPLETED") {
              notifications.push({
                id: `n_${nanoid(8)}`,
                sessionId: e.payload.sessionId,
                type: "SESSION_COMPLETED",
                sent: false,
                duplicatePrevented: true,
                at: Date.now(),
                channel: "n8n",
              });
            }
            return { ...e, status: "REJECTED_DUPLICATE" as const, rejectionReason: "Event already applied (idempotency)", syncedAt: Date.now() };
          }
          // apply task updates with conflict resolution
          if (e.type === "TASK_UPDATED") {
            const found = findTask(serverSubjects, e.payload.taskId);
            if (found) {
              const incoming = { status: e.payload.status as TaskStatus, version: e.payload.version as number, deviceId: e.deviceId };
              const existing = { status: found.task.status, version: found.task.version, deviceId: found.task.updatedBy };
              if (incoming.version > existing.version || (incoming.version === existing.version && incoming.deviceId > existing.deviceId)) {
                found.task.status = incoming.status;
                found.task.version = incoming.version;
                found.task.updatedAt = Date.now();
                found.task.updatedBy = incoming.deviceId;
                if (existing.version >= incoming.version - 1 && existing.status !== incoming.status && existing.version > 1) {
                  conflicts.push({
                    id: `cf_${nanoid(8)}`,
                    taskId: e.payload.taskId,
                    incoming, existing,
                    winning: incoming,
                    reason: incoming.version > existing.version ? "Higher logical version" : "Tie-break by device id",
                    at: Date.now(),
                  });
                }
              } else {
                conflicts.push({
                  id: `cf_${nanoid(8)}`,
                  taskId: e.payload.taskId,
                  incoming, existing,
                  winning: existing,
                  reason: "Incoming version lower — rejected",
                  at: Date.now(),
                });
              }
            }
          }
          if (e.type === "SESSION_COMPLETED") {
            notifications.push({
              id: `n_${nanoid(8)}`,
              sessionId: e.payload.sessionId,
              type: "SESSION_COMPLETED",
              sent: true,
              duplicatePrevented: false,
              at: Date.now(),
              channel: "n8n",
            });
          }
          applied.push({ eventId: e.id, type: e.type, appliedAt: Date.now() });
          serverVersion += 1;
          return { ...e, status: "SYNCED" as const, syncedAt: Date.now() };
        });

        set({
          queue: newQueue,
          serverEventsApplied: applied,
          serverSubjects,
          serverVersion,
          conflicts,
          notifications,
          lastSyncAt: Date.now(),
        });
      },

      replayLast: async () => {
        const q = get().queue;
        const last = [...q].reverse().find((e) => e.status === "SYNCED" || e.status === "REJECTED_DUPLICATE");
        if (!last) return;
        const replay: SyncEvent = { ...last, id: last.id, status: "PENDING", createdAt: Date.now(), syncedAt: undefined, rejectionReason: undefined };
        set({ queue: [...get().queue, replay] });
        await get().syncNow();
      },

      generateConflict: () => {
        // create a competing edit from "other device" on server side at a lower version
        const subjects = cloneSubjects(get().subjects);
        const allTasks: { task: Task }[] = [];
        for (const s of subjects) for (const c of s.chapters) for (const t of c.tasks) allTasks.push({ task: t });
        const pick = allTasks[Math.floor(Math.random() * allTasks.length)];
        if (!pick) return;
        // local moves to DONE at v+2
        const taskId = pick.task.id;
        const local = findTask(subjects, taskId)!;
        local.task.status = "DONE";
        local.task.version += 2;
        local.task.updatedBy = get().deviceId;
        local.task.updatedAt = Date.now();
        // server has IN_PROGRESS at v+1 (from "laptop")
        const serverSubjects = cloneSubjects(get().serverSubjects);
        const srv = findTask(serverSubjects, taskId)!;
        srv.task.status = "IN_PROGRESS";
        srv.task.version += 1;
        srv.task.updatedBy = "dev_laptop";
        srv.task.updatedAt = Date.now();

        set({ subjects, serverSubjects, localVersion: get().localVersion + 2 });
        get().enqueue({
          type: "TASK_UPDATED",
          payload: { taskId, status: "DONE" as TaskStatus, version: local.task.version },
        });
      },

      clearLocal: () => {
        set({
          queue: [],
          conflicts: [],
          notifications: [],
          subjects: seedSubjects(),
          localVersion: 1,
          coins: 0,
          streak: 0,
          todayFocusMinutes: 0,
          activeSession: null,
          lastSyncAt: null,
        });
      },
    }),
    {
      name: "alcovia-study-sync-v1",
    },
  ),
);
