export type TaskStatus = "NOT_STARTED" | "IN_PROGRESS" | "DONE";

export type SessionOutcome = "SUCCESS" | "FAILED";

export interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  version: number; // logical version (Lamport-ish)
  updatedAt: number;
  updatedBy: string; // device id
}

export interface Chapter {
  id: string;
  title: string;
  tasks: Task[];
}

export interface Subject {
  id: string;
  title: string;
  emoji: string;
  chapters: Chapter[];
}

export interface FocusSession {
  id: string; // idempotency key
  durationSec: number;
  startedAt: number;
  endedAt?: number;
  outcome?: SessionOutcome;
  coinsEarned: number;
  deviceId: string;
}

export type EventType =
  | "SESSION_STARTED"
  | "SESSION_COMPLETED"
  | "SESSION_FAILED"
  | "TASK_UPDATED";

export type SyncStatus = "PENDING" | "SYNCING" | "SYNCED" | "REJECTED_DUPLICATE";

export interface SyncEvent {
  id: string; // unique event id (idempotency)
  type: EventType;
  payload: any;
  deviceId: string;
  createdAt: number;
  logicalVersion: number;
  status: SyncStatus;
  syncedAt?: number;
  rejectionReason?: string;
}

export interface ConflictLog {
  id: string;
  taskId: string;
  incoming: { status: TaskStatus; version: number; deviceId: string };
  existing: { status: TaskStatus; version: number; deviceId: string };
  winning: { status: TaskStatus; version: number; deviceId: string };
  reason: string;
  at: number;
}

export interface NotificationLog {
  id: string;
  sessionId: string;
  type: "SESSION_COMPLETED" | "STREAK_MILESTONE";
  sent: boolean;
  duplicatePrevented: boolean;
  at: number;
  channel: "n8n";
}
