import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/app/Shell";
import { useSyncStore } from "@/lib/sync/store";
import { DeviceStateCard } from "@/components/app/DeviceStateCard";
import { EventLogCard } from "@/components/app/EventLogCard";
import { ConflictCard } from "@/components/app/ConflictCard";
import { NotificationCard } from "@/components/app/NotificationCard";

export const Route = createFileRoute("/dev")({
  head: () => ({ meta: [{ title: "Dev Panel · Alcovia" }, { name: "description", content: "Live state, sync queue, conflicts, and n8n notification logs." }] }),
  component: Dev,
});

function Dev() {
  const s = useSyncStore();

  return (
    <Shell>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Dev Panel</h1>
          <p className="mt-1 text-sm text-muted-foreground">Inspect & manipulate sync engine state. Use this during the demo.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Btn label={s.online ? "Go Offline" : "Go Online"} onClick={() => s.setOnline(!s.online)} tone={s.online ? "warning" : "success"} />
          <Btn label="Sync Now" onClick={() => void s.syncNow()} tone="primary" />
          <Btn label="Replay Last Event" onClick={() => void s.replayLast()} />
          <Btn label="Generate Conflict" onClick={s.generateConflict} tone="warning" />
          <Btn label="Clear Local State" onClick={s.clearLocal} tone="danger" />
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <DeviceStateCard />

        <div className="glass rounded-xl p-4 lg:col-span-2">
          <Header title="Sync Queue" count={s.queue.length} />
          <div className="mt-3 space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {s.queue.length === 0 && <Empty>No events yet. Try starting a focus session.</Empty>}
            {[...s.queue].reverse().map((e) => <EventLogCard key={e.id} event={e} />)}
          </div>
        </div>

        <div className="glass rounded-xl p-4 lg:col-span-2">
          <Header title="Conflict Logs" count={s.conflicts.length} />
          <div className="mt-3 space-y-2 max-h-[360px] overflow-y-auto pr-1">
            {s.conflicts.length === 0 && <Empty>No conflicts. Click <em>Generate Conflict</em>.</Empty>}
            {[...s.conflicts].reverse().map((c) => <ConflictCard key={c.id} conflict={c} />)}
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <Header title="n8n Notifications" count={s.notifications.length} />
          <div className="mt-3 space-y-2 max-h-[360px] overflow-y-auto pr-1">
            {s.notifications.length === 0 && <Empty>No notifications yet.</Empty>}
            {[...s.notifications].reverse().map((n) => <NotificationCard key={n.id} n={n} />)}
          </div>
        </div>
      </div>
    </Shell>
  );
}

function Header({ title, count }: { title: string; count: number }) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
      <span className="rounded-full bg-surface-2 px-2 py-0.5 text-xs tabular-nums">{count}</span>
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">{children}</div>;
}

function Btn({ label, onClick, tone = "default" }: { label: string; onClick: () => void; tone?: "default" | "primary" | "success" | "warning" | "danger" }) {
  const map: Record<string, string> = {
    default: "border-border text-foreground hover:bg-surface-2",
    primary: "border-primary/40 bg-primary/10 text-primary hover:bg-primary/15",
    success: "border-success/40 bg-success/10 text-success hover:bg-success/15",
    warning: "border-warning/40 bg-warning/10 text-warning hover:bg-warning/15",
    danger: "border-danger/40 bg-danger/10 text-danger hover:bg-danger/15",
  };
  return (
    <button onClick={onClick} className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition ${map[tone]}`}>
      {label}
    </button>
  );
}
