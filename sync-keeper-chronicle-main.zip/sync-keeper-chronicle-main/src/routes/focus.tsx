import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/app/Shell";
import { useSyncStore } from "@/lib/sync/store";
import { useEffect, useRef, useState } from "react";

export const Route = createFileRoute("/focus")({
  head: () => ({ meta: [{ title: "Focus · Alcovia" }, { name: "description", content: "Run a distraction-free focus session." }] }),
  component: Focus,
});

const DURATIONS = [
  { label: "5m", sec: 300 },
  { label: "15m", sec: 900 },
  { label: "25m", sec: 1500 },
  { label: "50m", sec: 3000 },
];

function Focus() {
  const session = useSyncStore((s) => s.activeSession);
  const start = useSyncStore((s) => s.startSession);
  const fail = useSyncStore((s) => s.failSession);
  const complete = useSyncStore((s) => s.completeSession);
  const tick = useSyncStore((s) => s.tickSession);
  const switches = useSyncStore((s) => s.appSwitchCount);
  const registerSwitch = useSyncStore((s) => s.registerAppSwitch);
  const demo = useSyncStore((s) => s.demoMode);
  const coins = useSyncStore((s) => s.coins);
  const streak = useSyncStore((s) => s.streak);

  const [pick, setPick] = useState(900);
  const [now, setNow] = useState(Date.now());
  const [justFinished, setJustFinished] = useState<null | "SUCCESS" | "FAILED">(null);
  const prevSessionId = useRef<string | null>(null);

  useEffect(() => {
    if (!session) return;
    const id = setInterval(() => {
      setNow(Date.now());
      tick();
    }, 200);
    return () => clearInterval(id);
  }, [session, tick]);

  // app-switch detection (visibility)
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "hidden" && session) registerSwitch();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [session, registerSwitch]);

  // success/failure animation hook
  useEffect(() => {
    if (session) {
      prevSessionId.current = session.id;
      setJustFinished(null);
    } else if (prevSessionId.current) {
      // we just finished; can't know outcome from store alone, infer from last queued event
      const last = useSyncStore.getState().queue.slice().reverse().find((e) => e.payload?.sessionId === prevSessionId.current);
      if (last?.type === "SESSION_COMPLETED") setJustFinished("SUCCESS");
      else if (last?.type === "SESSION_FAILED") setJustFinished("FAILED");
      prevSessionId.current = null;
    }
  }, [session]);

  const elapsed = session ? Math.min(session.durationSec, (now - session.startedAt) / 1000) : 0;
  const remaining = session ? Math.max(0, session.durationSec - elapsed) : pick;
  const progress = session ? elapsed / session.durationSec : 0;

  const mm = Math.floor(remaining / 60).toString().padStart(2, "0");
  const ss = Math.floor(remaining % 60).toString().padStart(2, "0");

  return (
    <Shell>
      <div className="mx-auto max-w-2xl">
        <div className="text-center">
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Focus Session</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {demo ? "Demo Mode active — sessions finish in seconds." : "Pick a duration, then go deep."}
          </p>
        </div>

        <div className="mt-8 glass rounded-2xl p-8">
          <div className="relative mx-auto h-64 w-64">
            <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
              <circle cx="50" cy="50" r="44" stroke="currentColor" strokeWidth="6" fill="none" className="text-border" />
              <circle
                cx="50" cy="50" r="44"
                stroke="currentColor" strokeWidth="6" fill="none" strokeLinecap="round"
                className={session ? "text-primary transition-[stroke-dashoffset] duration-200" : "text-primary"}
                strokeDasharray={2 * Math.PI * 44}
                strokeDashoffset={2 * Math.PI * 44 * (1 - progress)}
              />
            </svg>
            <div className="absolute inset-0 grid place-items-center">
              <div className="text-center">
                <div className="font-mono text-5xl tabular-nums">{mm}:{ss}</div>
                <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                  {session ? "remaining" : "ready"}
                </div>
              </div>
            </div>
          </div>

          {!session && (
            <>
              <div className="mt-6 grid grid-cols-4 gap-2">
                {DURATIONS.map((d) => (
                  <button
                    key={d.sec}
                    onClick={() => setPick(d.sec)}
                    className={`rounded-lg border px-3 py-2 text-sm font-medium transition ${
                      pick === d.sec ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {d.label}
                  </button>
                ))}
              </div>
              <button
                onClick={() => { setJustFinished(null); start(pick); }}
                className="mt-6 w-full rounded-lg bg-primary py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition hover:brightness-110"
              >
                Start session {demo && "(demo: ~8s)"}
              </button>
            </>
          )}

          {session && (
            <div className="mt-6 space-y-3">
              <div className="flex items-center justify-between rounded-lg border border-border bg-surface-2/40 px-3 py-2 text-xs">
                <span className="text-muted-foreground">App-switch detection</span>
                <span className={switches > 0 ? "text-warning" : "text-success"}>
                  {switches > 0 ? `⚠ ${switches} switch${switches > 1 ? "es" : ""}` : "✓ focused"}
                </span>
              </div>
              <button
                onClick={fail}
                className="w-full rounded-lg border border-danger/40 bg-danger/10 py-3 text-sm font-semibold text-danger transition hover:bg-danger/15"
              >
                Give up
              </button>
              <button
                onClick={complete}
                className="w-full rounded-lg border border-border py-2 text-xs text-muted-foreground hover:text-foreground"
              >
                (demo) finish now
              </button>
            </div>
          )}
        </div>

        {justFinished === "SUCCESS" && (
          <div className="mt-6 glass scale-in rounded-2xl border-success/30 p-6 text-center">
            <div className="text-4xl">🎉</div>
            <div className="mt-2 text-lg font-semibold text-success">Session complete</div>
            <div className="mt-3 grid grid-cols-3 gap-3 text-sm">
              <div><div className="text-muted-foreground text-xs">Coins</div><div className="font-semibold tabular-nums">{coins}</div></div>
              <div><div className="text-muted-foreground text-xs">Streak</div><div className="font-semibold tabular-nums">{streak}d</div></div>
              <div><div className="text-muted-foreground text-xs">Sync</div><div className="font-semibold">queued</div></div>
            </div>
          </div>
        )}
        {justFinished === "FAILED" && (
          <div className="mt-6 glass scale-in rounded-2xl border-danger/30 p-6 text-center">
            <div className="text-4xl">💔</div>
            <div className="mt-2 text-lg font-semibold text-danger">Session abandoned</div>
            <div className="mt-1 text-sm text-muted-foreground">No coins this round — try again.</div>
          </div>
        )}
      </div>
    </Shell>
  );
}
