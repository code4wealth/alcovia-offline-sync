import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/app/Shell";
import { MetricCard } from "@/components/app/MetricCard";
import { DeviceStateCard } from "@/components/app/DeviceStateCard";
import { useSyncStore } from "@/lib/sync/store";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard · Alcovia Study Sync" },
      { name: "description", content: "Offline-first study dashboard with multi-device sync and conflict resolution." },
    ],
  }),
  component: Index,
});

function Index() {
  const { streak, coins, todayFocusMinutes, online, lastSyncAt, queue } = useSyncStore();
  const pending = queue.filter((e) => e.status === "PENDING" || e.status === "SYNCING").length;
  const health = !online ? "Offline" : pending === 0 ? "Healthy" : "Catching up";
  const healthColor = !online ? "text-warning" : pending === 0 ? "text-success" : "text-primary";

  return (
    <Shell>
      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Good study, scholar.</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Everything works offline. Edits sync the moment you reconnect.
            </p>
          </div>
          <Link
            to="/focus"
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition hover:brightness-110"
          >
            Start focus session →
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          <MetricCard label="Current streak" value={`${streak}d`} accent="warning" hint="Keep it alive" icon="🔥" />
          <MetricCard label="Total coins" value={coins} accent="primary" hint="Earned from focus" icon="◆" />
          <MetricCard label="Focus today" value={`${todayFocusMinutes}m`} accent="success" hint="Minutes locked in" icon="⏱" />
          <MetricCard label="Pending events" value={pending} accent={pending ? "primary" : "default"} hint={lastSyncAt ? `Last sync ${new Date(lastSyncAt).toLocaleTimeString()}` : "Never synced"} icon="↻" />
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 glass rounded-xl p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Sync health</h2>
              <span className={`text-sm font-medium ${healthColor}`}>● {health}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {online
                ? "Your device is connected. Events flush automatically every action."
                : "You are offline. Actions are stored locally and will sync when you're back online."}
            </p>
            <div className="mt-4 grid grid-cols-3 gap-3 text-center">
              <Stat label="Synced" value={queue.filter((e) => e.status === "SYNCED").length} tone="success" />
              <Stat label="Pending" value={pending} tone="primary" />
              <Stat label="Duplicates" value={queue.filter((e) => e.status === "REJECTED_DUPLICATE").length} tone="danger" />
            </div>
            <Link to="/inspector" className="mt-4 inline-block text-xs text-primary hover:underline">Open Sync Inspector →</Link>
          </div>
          <DeviceStateCard />
        </div>
      </div>
    </Shell>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone: "success" | "primary" | "danger" }) {
  const map = { success: "text-success", primary: "text-primary", danger: "text-danger" };
  return (
    <div className="rounded-lg border border-border bg-surface-2/50 p-3">
      <div className={`text-2xl font-semibold tabular-nums ${map[tone]}`}>{value}</div>
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
