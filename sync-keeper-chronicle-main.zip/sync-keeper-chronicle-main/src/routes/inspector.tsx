import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/app/Shell";
import { useSyncStore } from "@/lib/sync/store";

export const Route = createFileRoute("/inspector")({
  head: () => ({ meta: [{ title: "Sync Inspector · Alcovia" }, { name: "description", content: "Side-by-side local vs server state." }] }),
  component: Inspector,
});

function Inspector() {
  const local = useSyncStore((s) => s.subjects);
  const server = useSyncStore((s) => s.serverSubjects);
  const queue = useSyncStore((s) => s.queue);
  const applied = useSyncStore((s) => s.serverEventsApplied);
  const lv = useSyncStore((s) => s.localVersion);
  const sv = useSyncStore((s) => s.serverVersion);

  const pending = queue.filter((e) => e.status === "PENDING" || e.status === "SYNCING");
  const rejected = queue.filter((e) => e.status === "REJECTED_DUPLICATE");

  const diffs: { taskId: string; local: string; server: string }[] = [];
  for (const s of local) for (const c of s.chapters) for (const t of c.tasks) {
    const srv = server.flatMap((x) => x.chapters).flatMap((x) => x.tasks).find((x) => x.id === t.id);
    if (srv && (srv.status !== t.status || srv.version !== t.version)) {
      diffs.push({ taskId: t.id, local: `${t.status} v${t.version}`, server: `${srv.status} v${srv.version}` });
    }
  }

  return (
    <Shell>
      <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Sync Inspector</h1>
      <p className="mt-1 text-sm text-muted-foreground">Live diff between this device and the server-of-record.</p>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Local version" value={`v${lv}`} />
        <Stat label="Server version" value={`v${sv}`} tone="primary" />
        <Stat label="Pending" value={pending.length} tone={pending.length ? "warning" : "default"} />
        <Stat label="Duplicates rejected" value={rejected.length} tone={rejected.length ? "danger" : "default"} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel title="Local State (this device)">
          <StateView subjects={local} />
        </Panel>
        <Panel title="Server State (source of truth)">
          <StateView subjects={server} />
        </Panel>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel title={`Differences (${diffs.length})`}>
          {diffs.length === 0 ? <div className="text-xs text-muted-foreground">In sync ✓</div> : (
            <ul className="space-y-2 text-xs">
              {diffs.map((d) => (
                <li key={d.taskId} className="rounded border border-warning/30 bg-warning/5 p-2">
                  <div className="font-mono text-[10px] text-muted-foreground">{d.taskId}</div>
                  <div className="mt-1 grid grid-cols-2 gap-2">
                    <div><div className="text-[10px] text-muted-foreground">Local</div><div className="font-mono">{d.local}</div></div>
                    <div><div className="text-[10px] text-muted-foreground">Server</div><div className="font-mono">{d.server}</div></div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel title={`Pending Queue (${pending.length})`}>
          <ul className="space-y-1.5 text-xs">
            {pending.length === 0 && <li className="text-muted-foreground">Empty</li>}
            {pending.map((e) => (
              <li key={e.id} className="rounded border border-border bg-surface-2/40 p-2 font-mono text-[11px]">
                <div>{e.type}</div>
                <div className="text-muted-foreground">{e.id}</div>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title={`Applied on Server (${applied.length})`}>
          <ul className="space-y-1.5 text-xs max-h-72 overflow-y-auto">
            {applied.length === 0 && <li className="text-muted-foreground">None</li>}
            {[...applied].reverse().map((a) => (
              <li key={a.eventId} className="rounded border border-border bg-surface-2/40 p-2 font-mono text-[11px]">
                <div>{a.type}</div>
                <div className="text-muted-foreground">{a.eventId}</div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      {rejected.length > 0 && (
        <div className="mt-6">
          <Panel title={`Rejected Duplicate Events (${rejected.length})`}>
            <ul className="space-y-1.5 text-xs">
              {rejected.map((e) => (
                <li key={e.id} className="rounded border border-danger/30 bg-danger/5 p-2 font-mono text-[11px]">
                  <div>{e.type} — {e.id}</div>
                  <div className="text-muted-foreground">{e.rejectionReason}</div>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      )}
    </Shell>
  );
}

function Stat({ label, value, tone = "default" }: { label: string; value: any; tone?: "default" | "primary" | "warning" | "danger" }) {
  const map = { default: "text-foreground", primary: "text-primary", warning: "text-warning", danger: "text-danger" };
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 text-2xl font-semibold tabular-nums ${map[tone]}`}>{value}</div>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-xl p-4">
      <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h3>
      <div className="mt-3">{children}</div>
    </div>
  );
}

function StateView({ subjects }: { subjects: ReturnType<typeof useSyncStore.getState>["subjects"] }) {
  return (
    <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1 text-xs">
      {subjects.map((s) => (
        <div key={s.id}>
          <div className="font-semibold text-sm">{s.emoji} {s.title}</div>
          <ul className="mt-1 ml-3 space-y-0.5">
            {s.chapters.flatMap((c) => c.tasks).map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-2 font-mono text-[11px]">
                <span className="truncate text-muted-foreground">{t.title}</span>
                <span className="shrink-0">{t.status} <span className="text-muted-foreground">v{t.version}</span></span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
