import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/app/Shell";
import { useSyncStore } from "@/lib/sync/store";
import type { TaskStatus } from "@/lib/sync/types";

export const Route = createFileRoute("/syllabus")({
  head: () => ({ meta: [{ title: "Syllabus · Alcovia" }, { name: "description", content: "Subjects, chapters, tasks with versioned conflict resolution." }] }),
  component: Syllabus,
});

const statusOrder: TaskStatus[] = ["NOT_STARTED", "IN_PROGRESS", "DONE"];
const statusLabel: Record<TaskStatus, string> = {
  NOT_STARTED: "Not started",
  IN_PROGRESS: "In progress",
  DONE: "Done",
};
const statusTone: Record<TaskStatus, string> = {
  NOT_STARTED: "border-border text-muted-foreground",
  IN_PROGRESS: "border-warning/40 bg-warning/10 text-warning",
  DONE: "border-success/40 bg-success/10 text-success",
};

function nextStatus(s: TaskStatus): TaskStatus {
  return statusOrder[(statusOrder.indexOf(s) + 1) % statusOrder.length];
}

function Syllabus() {
  const subjects = useSyncStore((s) => s.subjects);
  const updateTask = useSyncStore((s) => s.updateTask);
  const localVersion = useSyncStore((s) => s.localVersion);

  return (
    <Shell>
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">Syllabus Progress</h1>
          <p className="mt-1 text-sm text-muted-foreground">Tap a task status to cycle. Each edit increments its logical version.</p>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <div>Doc version <span className="font-mono text-foreground">v{localVersion}</span></div>
        </div>
      </div>

      <div className="mt-6 space-y-4">
        {subjects.map((s) => {
          const allTasks = s.chapters.flatMap((c) => c.tasks);
          const done = allTasks.filter((t) => t.status === "DONE").length;
          const pct = Math.round((done / allTasks.length) * 100);
          return (
            <div key={s.id} className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-surface-2 text-lg">{s.emoji}</div>
                  <div>
                    <h2 className="text-lg font-semibold">{s.title}</h2>
                    <div className="text-xs text-muted-foreground">{done}/{allTasks.length} tasks complete</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-semibold tabular-nums">{pct}%</div>
                </div>
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-2">
                <div className="h-full bg-gradient-to-r from-primary to-success transition-[width] duration-500" style={{ width: `${pct}%` }} />
              </div>

              <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-2">
                {s.chapters.map((c) => {
                  const cDone = c.tasks.filter((t) => t.status === "DONE").length;
                  const cPct = Math.round((cDone / c.tasks.length) * 100);
                  return (
                    <div key={c.id} className="rounded-xl border border-border bg-surface-2/40 p-4">
                      <div className="flex items-center justify-between">
                        <div className="font-medium">{c.title}</div>
                        <div className="text-xs text-muted-foreground tabular-nums">{cPct}%</div>
                      </div>
                      <div className="mt-2 h-1 overflow-hidden rounded-full bg-background">
                        <div className="h-full bg-primary" style={{ width: `${cPct}%` }} />
                      </div>
                      <ul className="mt-3 space-y-1.5">
                        {c.tasks.map((t) => (
                          <li key={t.id} className="flex items-center justify-between gap-3 rounded-lg px-2 py-1.5 hover:bg-background/50">
                            <div className="min-w-0">
                              <div className="truncate text-sm">{t.title}</div>
                              <div className="text-[10px] text-muted-foreground">
                                v{t.version} · updated {new Date(t.updatedAt).toLocaleTimeString()} · <span className="font-mono">{t.updatedBy}</span>
                              </div>
                            </div>
                            <button
                              onClick={() => updateTask(t.id, nextStatus(t.status))}
                              className={`shrink-0 rounded-md border px-2 py-1 text-[11px] font-medium transition ${statusTone[t.status]}`}
                            >
                              {statusLabel[t.status]}
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </Shell>
  );
}
